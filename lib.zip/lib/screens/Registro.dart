import 'package:flutter/material.dart';
void main(){
  runApp(Registro());
}
class Registro extends StatelessWidget {
  const Registro({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Home()
    );
  }
}
class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registro'),
      ),
      body: Cuerpo(),
    );
  }
}
Widget Cuerpo(){
  return(
    Column(
      children: <Widget>[
        User(),
        Password()
      ],
    )
  );
}
final TextEditingController _users = TextEditingController();
Widget User (){
  return(
    TextField(
      controller: _users,
      decoration:InputDecoration(hintText: "Ingrese su usuario"),
    )
  );
}
final TextEditingController _password = TextEditingController();
Widget Password (){
  return(
    TextField(
    controller: _password,
    decoration:InputDecoration(hintText: "Ingrese su contraseña"),
    )
  );
}